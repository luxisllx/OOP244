// DebugGemA.cpp
#include <iostream>
#include "DebugGemA.h"

gem::gem(double wt, int sh, const char* nm){
  weight = wt;
  shine = sh;
}
int gem::getWeight() const{
  return weight;
}
void gem::polish(int po) const{
  shine += po;
}
void gem::display() const{
  cout << "W: " << weight << " S:" << shine << endl;
}

bool shiny(const gem& g){
  return g.shine > 50;
}