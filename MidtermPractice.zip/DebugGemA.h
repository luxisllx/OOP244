// DebugGemA.h
#ifndef MIDTERM_GEM_H
#define MIDTERM_GEM_H

namespace midterm{

  class gem{

    double weight;
    int shine;

    public:
      gem(double wt = 1.5, int sh, const char* nm);
      double getWeight();
      void polish(int po);
      void display() const;
  };

bool shiny(const gem& g);
};

#endif