// WalkA.cpp
#include <iostream>
using namespace std;

class playdoh {
  int weight;
  public:
    playdoh(int w = 5){
      weight = w;
      cout << "Doh: " << weight << endl;
    }

    void add(){
      weight += 6;
      cout << "Play: " << weight << endl;
    }

    ~playdoh(){
      weight -= 4;
      cout << "Clay: " << weight << endl;
    }
};

void mixup(playdoh doh1, playdoh& doh2){
  doh1.add();
  doh2.add();
}

int main(){

  playdoh p1(15);
  playdoh p2;

  cout << "**************" << endl;
  mixup(p1, p2);
  cout << "**************" << endl;
  mixup(p2, p1);
  cout << "**************" << endl;

  return 0;
}